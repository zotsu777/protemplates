(function () {
  var STORAGE_KEY = "atlas-template-lang";
  var html = document.documentElement;

  function apply(lang) {
    var ar = lang === "ar";
    html.lang = ar ? "ar" : "fr";
    html.dir = ar ? "rtl" : "ltr";
    document.querySelectorAll("[data-fr][data-ar]").forEach(function (node) {
      var value = node.getAttribute(ar ? "data-ar" : "data-fr");
      if (value !== null) node.textContent = value;
    });
    document.querySelectorAll("[data-lang]").forEach(function (button) {
      button.setAttribute("aria-pressed", String(button.dataset.lang === lang));
    });
    try { localStorage.setItem(STORAGE_KEY, lang); } catch (error) {}
  }

  var stored = null;
  try { stored = localStorage.getItem(STORAGE_KEY); } catch (error) {}
  if (stored === "ar") apply("ar");

  document.querySelectorAll("[data-lang]").forEach(function (button) {
    button.addEventListener("click", function () { apply(button.dataset.lang); });
  });

  var header = document.getElementById("site-header");
  var toggle = document.querySelector(".nav-toggle");
  if (header && toggle) {
    toggle.addEventListener("click", function () {
      var open = header.classList.toggle("open");
      toggle.setAttribute("aria-expanded", String(open));
    });
    header.querySelectorAll(".nav-links a").forEach(function (link) {
      link.addEventListener("click", function () {
        header.classList.remove("open");
        toggle.setAttribute("aria-expanded", "false");
      });
    });
  }

  var form = document.querySelector("form[data-demo-form]");
  if (form) {
    form.addEventListener("submit", function (event) {
      event.preventDefault();
      var status = form.querySelector(".form-status");
      var ar = html.lang === "ar";
      if (status) {
        status.textContent = ar
          ? "شكراً! هذه نسخة تجريبية — اربط الاستمارة بخدمة بريدك أو واتساب."
          : "Merci ! Ceci est une démo — connectez le formulaire à votre service e-mail ou WhatsApp.";
      }
      form.reset();
    });
  }

  var year = document.querySelector("[data-year]");
  if (year) year.textContent = String(new Date().getFullYear());
})();
